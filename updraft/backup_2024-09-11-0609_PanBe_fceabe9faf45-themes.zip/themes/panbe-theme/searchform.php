<div class="d-flex justify-content-center pt-4">
    <form method="get" action="<?php echo esc_url(site_url('/')); ?>" class="form-inline">
        <input class="form-control mr-sm-2" type="search" name="s" placeholder="What are you looking for?">
        <input class="btn btn-dark my-2 my-sm-0" type="submit" value="search">
    </form>
</div>